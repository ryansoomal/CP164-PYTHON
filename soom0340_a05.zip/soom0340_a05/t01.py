"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ryan Soomal
ID:      210370340
Email:   soom0340@mylaurier.ca
__updated__ = "2021-02-25"
-------------------------------------------------------
"""
from List_array import List
l = List()
l.append(11)
l.append(22)
print(l._is_valid_index(0))


print(l._values)