"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ryan Soomal
ID:      210370340
Email:   soom0340@mylaurier.ca
__updated__ = "2021-02-25"
-------------------------------------------------------
"""
from Sorted_List_array import Sorted_List
s = Sorted_List()
s._values = [1,2,3,4,5,6]
print(s._values)
print(s._binary_search(3))