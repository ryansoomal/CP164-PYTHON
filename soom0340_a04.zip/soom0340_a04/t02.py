"""
-------------------------------------------------------
[t02]
-------------------------------------------------------
Author:  Ryan Soomal
ID:      210370340
Email:   soom0340@mylaurier.ca
__updated__ = "2021-01-29"
-------------------------------------------------------
"""
from Stack_array import Stack
def main():
    s = Stack()
    l = [1,2,3,4,5,6]  
    for v in l:
        s.push(v)
    target1,target2 = s.split_alt()
    print(target1)
    print(target2)
    
main()