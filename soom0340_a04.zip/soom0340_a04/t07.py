"""
-------------------------------------------------------
[t07]
-------------------------------------------------------
Author:  Ryan Soomal
ID:      210370340
Email:   soom0340@mylaurier.ca
__updated__ = "2021-01-30"
-------------------------------------------------------
"""
from functions import stack_maze
def main():
    maze = {'Start': ['A'], 'A':['C', 'B'], 
            'B':[], 'C':['D', 'X']}
    path = stack_maze(maze)
    print(path)
main()