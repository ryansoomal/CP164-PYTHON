"""
-------------------------------------------------------
[t03]
-------------------------------------------------------
Author:  Ryan Soomal
ID:      210370340
Email:   soom0340@mylaurier.ca
__updated__ = "2021-01-09"
-------------------------------------------------------
"""
from functions import matrix_stats
def main():
    print(matrix_stats([[1,2],[2,2]]))
    
main()