"""
-------------------------------------------------------
[t04]
-------------------------------------------------------
Author:  Ryan Soomal
ID:      210370340
Email:   soom0340@mylaurier.ca
__updated__ = "2021-01-12"
-------------------------------------------------------
"""
from functions import matrix_flatten
def main():
    print(matrix_flatten([["a", "b"], ["x", "z"], ["e", "f"]]))
    
main()