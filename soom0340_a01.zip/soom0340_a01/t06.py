"""
-------------------------------------------------------
[t06]
-------------------------------------------------------
Author:  Ryan Soomal
ID:      210370340
Email:   soom0340@mylaurier.ca
__updated__ = "2021-01-14"
-------------------------------------------------------
"""
from functions import matrixes_multiply
def main():
    a = [[1,2,3],
         [4,5,6]]
    b = [[7,8],
         [9,10],
         [11,12]]
    print(matrixes_multiply(a, b))
    
main()