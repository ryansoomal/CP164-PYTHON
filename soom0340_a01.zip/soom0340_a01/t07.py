"""
-------------------------------------------------------
[t07]
-------------------------------------------------------
Author:  Ryan Soomal
ID:      210370340
Email:   soom0340@mylaurier.ca
__updated__ = "2021-01-14"
-------------------------------------------------------
"""
from functions import matrix_rotate_right
def main():
    print(matrix_rotate_right([[1,2,3],[4,5,6],[7,8,9],[10,12,12]]))
    
main()