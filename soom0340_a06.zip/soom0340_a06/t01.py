"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ryan Soomal
ID:      210370340
Email:   soom0340@mylaurier.ca
__updated__ = "2021-03-04"
-------------------------------------------------------
"""
from List_linked import List
l = List()
l.append(44)

t1,t2 = l.split()



#l.clean()
for i in t1:
    print(i)
print()
for j in t2:
    print(j)
'''
val = l.remove_front()
for i in l:
    print(i)
    
print()
print(val)
'''