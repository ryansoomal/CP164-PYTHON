"""
-------------------------------------------------------
[t06]
-------------------------------------------------------
Author:  Ryan Soomal
ID:      210370340
Email:   soom0340@mylaurier.ca
__updated__ = "2021-01-30"
-------------------------------------------------------
"""
from functions import postfix
def main():
    string = "4 5.2 + "
    answer = postfix(string)
    print(answer)
main()