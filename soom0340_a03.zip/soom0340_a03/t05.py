"""
-------------------------------------------------------
[t05]
-------------------------------------------------------
Author:  Ryan Soomal
ID:      210370340
Email:   soom0340@mylaurier.ca
__updated__ = "2021-01-30"
-------------------------------------------------------
"""
from functions import is_palindrome_stack
def main():
    s = "nope"
    print(is_palindrome_stack(s))
    
    
main()